//import com.bethecoder.ascii_table.ASCIITable;
//import java.util.*;
//import java.sql.*;
//
//public class test2 {
//    static String Title;
//    static Scanner sc = new Scanner(System.in);
//    static final String url = "jdbc:mysql://localhost:3306/neerajdb";
//    static final String username = "root";
//    static final String password = "12345678";
//    static int quantity;
//    static String Title1;
//
//    public static void main (String[]args) throws ClassNotFoundException, SQLException{
//        System.out.println(" 1. Comics\n 2. Programming Books\n 3. Engineering Books\n 4. Best Sellers\n 5. Famous People Recommends\n 6. Science Fiction\n 7. Bohemian Literature\n 8. Everyday Reads\n 9. Back <<<");
//        int x1 = sc.nextInt();
//        switch (x1){
//            case 1:
//                Comics();
//                break;
//             case 2:
//                 Programming_Books.Programming_books();
//                 break;
//             case 3:
//                 Engineeringbooks.Engineering_books();
//                 break;
//             case 4:
//                 Best_sellers.Best_Sellers();
//                 break;
//             case 5:
//                 Famouspep_recommend.Famouspeople_recommends();
//                 break;
//             case 6:
//                 Science_Fiction.Science_fiction();
//                 break;
//            case 10:
//                Aliens_Scifi();
//                 case 7:
//                     bohemian_literature.Bohemian_literature();
//                     break;
//                 case 8:
//                     everydayreads.Everydayreads();
//                     break;
//                 case 9:
//                     Library.library();
//                 default:
//                     System.out.println("\033[0;1m" + "Wrong Entry.... "+ "\u001B[0m");
//                     System.out.println("you are redireted to Mainpage....");
//                     Mainpage.mainpage();
//                     break;
//        }
//
//
//    }
//    public static void Aliens_Scifi() throws SQLException, ClassNotFoundException{
//        Connection connection = DriverManager.getConnection(url, username, password);
//        Class.forName("com.mysql.cj.jdbc.Driver");
//        int numb = 0;
//        int pass = 0;
//        while (numb == pass) {
//            System.out.println("Enter the Title: ");
//            Title = Main.sc.nextLine();
//            if (Title.equals("")) {
//                System.out.println("\033[0;1m" + "Enter Title to continue \n" + "\u001B[0m");
//                pass = 0;
//            } else {
//                pass = 1;
//            }
//        }
//        String query= "SELECT*FROM aliens_sifi WHERE Title LIKE '"+Title+"'";
//        Statement stm =connection.createStatement();
//        ResultSet rs= stm.executeQuery(query);
//
//        while (rs.next()) {
//            Title1 = rs.getString(1);
//            String Author = rs.getString(2);
//            String Language = rs.getString(3);
//            String Rating = rs.getString(4);
//            String Voters = rs.getString(5);
//            String Year = rs.getString(6);
//            quantity = rs.getInt(10);
//            String [] tableHeaders = { "Title","Author", "Language", "Rating", "Voters","Year"};
//            String[][] tableData = {
//                    {  Title1,Author,Language,Rating,Voters,Year }
//            };
//            System.out.println(quantity+"Quantity");
//            ASCIITable.getInstance().printTable(tableHeaders, tableData);
//        }
//        System.out.println(" 1. Take Book\n 2. Cancel...");
//        int y = sc.nextInt();
//        if(y == 1){
//            if(quantity > 0){
//                //  String issuequery = "update aliens_sifi set quantity=quantity-1 WHERE Title="+Title1+";";
//                // ResultSet rs1= stm.executeQuery("update aliens_sifi set quantity=quantity-1 WHERE Title="+Title+";");
//                // System.out.println("Book Issued...");
//                ALiens_Takebook();
//            }
//            else{
//                System.out.println("Currently Book Not available...");
//                // Search_books()
//            }
//        }
//
//    }
//    public static void ALiens_Takebook() throws SQLException{
//        System.out.println(Title1);
//        Connection connection = DriverManager.getConnection(url, username, password);
//        try {
//            Class.forName("com.mysql.cj.jdbc.Driver");
//        } catch (ClassNotFoundException e) {
//            System.out.println(" ");
//        }
//        Statement st = connection.createStatement();
//        String issuequery = "UPDATE aliens_sifi SET quantity = quantity - 1 WHERE Title LIKE '"+Title1+"';";
//        ResultSet rs1 = st.executeQuery(issuequery);
//        rs1.next();
//    }
//
//    public static void Comics() throws SQLException, ClassNotFoundException{
//        Connection connection = DriverManager.getConnection(url, username, password);
//        Class.forName("com.mysql.cj.jdbc.Driver");
//        int numb = 0;
//        int pass = 0;
//        while (numb == pass) {
//            System.out.println("Enter the Title: ");
//            Title = Main.sc.nextLine();
//            if (Title.equals("")) {
//                System.out.println("\033[0;1m" + "Enter Title to continue \n" + "\u001B[0m");
//                pass = 0;
//            } else {
//                pass = 1;
//            }
//        }
//        String query= "SELECT*FROM marvel_comics WHERE Title='"+Title+"'";
//        Statement stm =connection.createStatement();
//        ResultSet rs= stm.executeQuery(query);
//        while (rs.next()) {
//            String name = rs.getString(1);
//            String issuedtitle = rs.getString(3);
//            String penciler = rs.getString(5);
//            String writer = rs.getString(6);
//            String coverartist = rs.getString(7);
//            String activeyear = rs.getString(2);
//            String publishedyear = rs.getString(4);
//            String Imprint = rs.getString(8);
//            String format = rs.getString(9);
//            String rating = rs.getString(10);
//            String [] tableHeaders = { "Comic_Name","Issued Title", "Penciler", "Writer", "CoverArtist","ActiveYear","Published Year","Imprint","Format","Rating"};
//            String[][] tableData = {
//                    {  name,issuedtitle,penciler,writer,coverartist,activeyear,publishedyear,Imprint,format,rating }
//
//
//            };
//            ASCIITable.getInstance().printTable(tableHeaders, tableData);
//        }
//
//    }
//}