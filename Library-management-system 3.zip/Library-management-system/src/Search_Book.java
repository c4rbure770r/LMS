import com.bethecoder.ascii_table.ASCIITable;

import java.sql.*;

public class Search_Book {
    static String Title;
    static final String url = "jdbc:mysql://localhost:3306/neerajdb";
    static final String username = "root";
    static final String password = "12345678";
    public static void main(String[]args) throws SQLException, ClassNotFoundException {
        Connection connection = DriverManager.getConnection(url, username, password);
        Class.forName("com.mysql.cj.jdbc.Driver");
        int numb = 0;
        int pass = 0;
        while (numb == pass) {
            System.out.println("Enter the Title: ");
            Title = Main.sc.nextLine();
            if (Title.equals("")) {
                System.out.println("\033[0;1m" + "Enter Title to continue \n" + "\u001B[0m");
                pass = 0;
            } else {
                pass = 1;
            }
        }
        String query= "SELECT*FROM aliens_sifi WHERE Title='"+Title+"'";
        Statement stm =connection.createStatement();
        ResultSet rs= stm.executeQuery(query);
        while (rs.next()) {
            String Title1 = rs.getString(1);
            String Author = rs.getString(2);
            String Language = rs.getString(3);
            String Rating = rs.getString(4);
            String Voters = rs.getString(5);
            String Year = rs.getString(6);
            String [] tableHeaders = { "Title","Author", "Language", "Rating", "Voters","Year"};
            String[][] tableData = {
                    {  Title1,Author,Language,Rating,Voters,Year }


            };
            ASCIITable.getInstance().printTable(tableHeaders, tableData);
        }



    }
}
